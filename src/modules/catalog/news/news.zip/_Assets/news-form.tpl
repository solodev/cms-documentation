<div class="mb-3">
  <label class="control-label" for="news_intro">News Intro</label>
  <p class="small">(Required) Content that appears before the Body Content and the introductory paragraph on the news feed.</p>
  <input class="form-control" id="news_intro" name="news_intro" type="text">
</div>
<div class="row">
  <div class="col-md-6 form-group">
    <label class="control-label" for="news_image">News Image</label>
    <p class="small">(Optional) The image that appears in the news article and normal news feed.</p>
    <input class="file_upload" id="news_image" name="news_image" type="file">
  </div>
  <div class="col-md-6 mb-3">
    <label class="control-label" for="news_image_alt_tag">Image Alt Tag</label>
    <p class="small">(Required) Descriptive text for screen readers and accessibility.</p>
    <input class="form-control" id="news_image_alt_tag" name="news_image_alt_tag" type="text">
  </div>
</div>
<div class="mb-3">
  <label class="control-label" for="news_content">Body Content</label>
  <p class="small">(Required) The main content section for an article.</p>
  <textarea class="form-control wysiwyg-wp" id="news_content" name="news_content"></textarea>
</div>